package com.example.callblocker

import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LogActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "سجل المكالمات المحظورة"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(24))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(Button(this).apply {
            text = "مسح السجل"
            setOnClickListener {
                LogStore.clear(this@LogActivity)
                refresh()
            }
        })

        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(container)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        container.removeAllViews()
        val entries = LogStore.list(this)
        if (entries.isEmpty()) {
            container.addView(bodyView("لا توجد مكالمات محظورة بعد."))
            return
        }
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH)
        for (e in entries) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(12), 0, dp(12))
            }
            box.addView(TextView(this).apply {
                text = e.number
                textSize = 18f
                setTypeface(null, Typeface.BOLD)
            })
            box.addView(bodyView(
                "آخر محاولة: ${fmt.format(Date(e.last))}\n" +
                        "عدد المحاولات: ${e.count}\n" +
                        "السبب: ${LogStore.label(e.reason)}"
            ))
            box.addView(Button(this).apply {
                text = "إضافة للقائمة البيضاء"
                setOnClickListener {
                    Settings.addToList(this@LogActivity, Settings.WHITE, e.number)
                    Toast.makeText(this@LogActivity, "تمت الإضافة للقائمة البيضاء", Toast.LENGTH_SHORT).show()
                }
            })
            container.addView(box)
        }
    }
}
