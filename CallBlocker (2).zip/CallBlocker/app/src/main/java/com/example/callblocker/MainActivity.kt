package com.example.callblocker

import android.Manifest
import android.app.TimePickerDialog
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusView: TextView
    private lateinit var contactsSwitch: SwitchCompat
    private lateinit var notifySwitch: SwitchCompat
    private lateinit var hoursBox: LinearLayout
    private lateinit var startBtn: Button
    private lateinit var endBtn: Button
    private lateinit var messageInput: EditText
    private lateinit var whiteContainer: LinearLayout
    private lateinit var blackContainer: LinearLayout

    // ---------- المشغّلات (Launchers) ----------
    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            updateStatus()
        }

    private val smsPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            requestCallScreeningRole()
        }

    private val contactsPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            Settings.setContactsExempt(this, granted)
            if (!granted) {
                contactsSwitch.isChecked = false
                toast("لم تُمنح صلاحية جهات الاتصال")
            }
        }

    private val notifyPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            Settings.setNotify(this, granted)
            if (!granted) {
                notifySwitch.isChecked = false
                toast("لم تُمنح صلاحية الإشعارات")
            }
        }

    private val contactPickerLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = result.data?.data ?: return@registerForActivityResult
            contentResolver.query(
                uri,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val number = c.getString(0) ?: return@use
                    if (Settings.addToList(this, Settings.WHITE, number)) {
                        refreshLists()
                    }
                }
            }
        }

    // ---------- أدوات ----------
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hasPerm(p: String) =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun parseInt(s: String): Int? =
        s.mapNotNull { ch -> Character.digit(ch, 10).takeIf { it >= 0 } }
            .joinToString("").toIntOrNull()

    // ---------- الإنشاء ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        // ----- العنوان والحالة -----
        root.addView(titleView("حظر المكالمات المتكررة"))
        root.addView(bodyView(
            "يمرّر المكالمات الأولى ويرفض المتكررة خلال المدة المحددة، " +
                    "ويرسل للمتصل رسالة تطلب منه الاتصال لاحقاً."
        ))
        statusView = bodyView("").apply { textSize = 17f }
        root.addView(statusView)
        root.addView(Button(this).apply {
            text = "تفعيل الصلاحيات"
            setOnClickListener { enable() }
        })

        // ----- المفتاح السريع -----
        root.addView(SwitchCompat(this).apply {
            text = "تشغيل الحظر"
            textSize = 18f
            setPadding(0, dp(16), 0, dp(8))
            isChecked = Settings.isEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                Settings.setEnabled(this@MainActivity, checked)
            }
        })

        // ----- سجل المكالمات -----
        root.addView(Button(this).apply {
            text = "سجل المكالمات المحظورة"
            setOnClickListener { startActivity(Intent(this@MainActivity, LogActivity::class.java)) }
        })

        // ----- المدة وعدد المكالمات -----
        addNumberSetting(root, "مدة الحظر (بالدقائق)", Settings.getMinutes(this), 1, 1440) {
            Settings.setMinutes(this, it)
        }
        addNumberSetting(root, "عدد المكالمات المسموحة قبل الحظر", Settings.getMaxCalls(this), 1, 20) {
            Settings.setMaxCalls(this, it)
        }

        // ----- ساعات التفعيل -----
        root.addView(titleView("ساعات التفعيل"))
        val allDay = Settings.isAllDay(this)
        val allDaySwitch = SwitchCompat(this).apply {
            text = "اليوم كله"
            isChecked = allDay
        }
        root.addView(allDaySwitch)

        hoursBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = if (allDay) View.GONE else View.VISIBLE
        }
        startBtn = Button(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { pickTime(true) }
        }
        endBtn = Button(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { pickTime(false) }
        }
        hoursBox.addView(startBtn)
        hoursBox.addView(endBtn)
        root.addView(hoursBox)
        updateHoursButtons()

        allDaySwitch.setOnCheckedChangeListener { _, checked ->
            Settings.setAllDay(this, checked)
            hoursBox.visibility = if (checked) View.GONE else View.VISIBLE
        }
        root.addView(bodyView("خارج هذه الساعات تمرّ كل المكالمات (ما عدا القائمة السوداء)."))

        // ----- خيارات إضافية -----
        root.addView(titleView("خيارات إضافية"))
        contactsSwitch = SwitchCompat(this).apply {
            text = "لا تحظر أرقام جهات الاتصال المحفوظة"
            isChecked = Settings.isContactsExempt(this@MainActivity) &&
                    hasPerm(Manifest.permission.READ_CONTACTS)
            setOnCheckedChangeListener { _, checked ->
                when {
                    !checked -> Settings.setContactsExempt(this@MainActivity, false)
                    hasPerm(Manifest.permission.READ_CONTACTS) ->
                        Settings.setContactsExempt(this@MainActivity, true)
                    else -> contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
                }
            }
        }
        root.addView(contactsSwitch)

        notifySwitch = SwitchCompat(this).apply {
            text = "إشعار عند حظر مكالمة"
            isChecked = Settings.isNotifyEnabled(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                when {
                    !checked -> Settings.setNotify(this@MainActivity, false)
                    Build.VERSION.SDK_INT < 33 ||
                            hasPerm(Manifest.permission.POST_NOTIFICATIONS) ->
                        Settings.setNotify(this@MainActivity, true)
                    else -> notifyPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
        root.addView(notifySwitch)

        // ----- نص الرسالة -----
        root.addView(titleView("نص الرسالة"))
        root.addView(bodyView("اكتب ${Settings.DURATION_TAG} في أي مكان ليحل محله وقت الانتظار تلقائياً."))
        messageInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 2
            setText(Settings.getCustomMessage(this@MainActivity).ifBlank { Settings.DEFAULT_TEMPLATE })
        }
        root.addView(messageInput)
        val msgRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        msgRow.addView(Button(this).apply {
            text = "حفظ النص"
            setOnClickListener { saveMessage() }
        })
        msgRow.addView(Button(this).apply {
            text = "النص الافتراضي"
            setOnClickListener {
                Settings.setCustomMessage(this@MainActivity, "")
                messageInput.setText(Settings.DEFAULT_TEMPLATE)
                toast("تمت استعادة النص الافتراضي")
            }
        })
        root.addView(msgRow)

        // ----- القائمة البيضاء -----
        whiteContainer = addListSection(
            root, "القائمة البيضاء (لا تُحظر أبداً)", Settings.WHITE, true
        )
        // ----- القائمة السوداء -----
        blackContainer = addListSection(
            root, "القائمة السوداء (تُحظر دائماً بلا رسالة)", Settings.BLACK, false
        )

        refreshLists()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    // ---------- التفعيل ----------
    private fun enable() {
        if (!hasPerm(Manifest.permission.SEND_SMS)) {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
        } else {
            requestCallScreeningRole()
        }
    }

    private fun requestCallScreeningRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
            !rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        ) {
            roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
        } else {
            updateStatus()
        }
    }

    private fun updateStatus() {
        val rm = getSystemService(RoleManager::class.java)
        val roleOk = rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        val smsOk = hasPerm(Manifest.permission.SEND_SMS)
        statusView.text = when {
            roleOk && smsOk -> "الحالة: مفعّل ✅"
            roleOk -> "الحالة: الحظر يعمل لكن صلاحية الرسائل غير مفعّلة ⚠️"
            else -> "الحالة: غير مفعّل ❌"
        }
    }

    // ---------- إعداد رقمي ----------
    private fun addNumberSetting(
        root: LinearLayout, label: String, initial: Int, min: Int, max: Int,
        onSave: (Int) -> Unit
    ) {
        root.addView(titleView(label))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(initial.toString())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        row.addView(input)
        row.addView(Button(this).apply {
            text = "حفظ"
            setOnClickListener {
                val v = parseInt(input.text.toString())
                if (v == null || v < min || v > max) {
                    toast("أدخل قيمة من $min إلى $max")
                } else {
                    onSave(v)
                    input.setText(v.toString())
                    toast("تم الحفظ")
                }
            }
        })
        root.addView(row)
    }

    // ---------- ساعات التفعيل ----------
    private fun updateHoursButtons() {
        startBtn.text = "من: ${Settings.formatTime(Settings.getStart(this))}"
        endBtn.text = "إلى: ${Settings.formatTime(Settings.getEnd(this))}"
    }

    private fun pickTime(isStart: Boolean) {
        val cur = if (isStart) Settings.getStart(this) else Settings.getEnd(this)
        TimePickerDialog(this, { _, h, m ->
            val v = h * 60 + m
            if (isStart) Settings.setStart(this, v) else Settings.setEnd(this, v)
            updateHoursButtons()
        }, cur / 60, cur % 60, true).show()
    }

    // ---------- نص الرسالة ----------
    private fun saveMessage() {
        val t = messageInput.text.toString().trim()
        if (t.isEmpty() || t == Settings.DEFAULT_TEMPLATE) {
            Settings.setCustomMessage(this, "")
            messageInput.setText(Settings.DEFAULT_TEMPLATE)
        } else {
            Settings.setCustomMessage(this, t)
        }
        toast("تم حفظ النص")
    }

    // ---------- القوائم ----------
    private fun addListSection(
        root: LinearLayout, heading: String, listKey: String, withContacts: Boolean
    ): LinearLayout {
        root.addView(titleView(heading))

        val addRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply {
            hint = "رقم الهاتف"
            inputType = InputType.TYPE_CLASS_PHONE
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        addRow.addView(input)
        addRow.addView(Button(this).apply {
            text = "إضافة"
            setOnClickListener {
                if (Settings.addToList(this@MainActivity, listKey, input.text.toString())) {
                    input.setText("")
                    refreshLists()
                } else {
                    toast("رقم غير صالح")
                }
            }
        })
        root.addView(addRow)

        if (withContacts) {
            root.addView(Button(this).apply {
                text = "اختيار من جهات الاتصال"
                setOnClickListener {
                    contactPickerLauncher.launch(
                        Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
                    )
                }
            })
        }

        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(container)
        return container
    }

    private fun refreshLists() {
        renderList(whiteContainer, Settings.WHITE)
        renderList(blackContainer, Settings.BLACK)
    }

    private fun renderList(container: LinearLayout, listKey: String) {
        container.removeAllViews()
        val numbers = Settings.getList(this, listKey)
        if (numbers.isEmpty()) {
            container.addView(bodyView("لا توجد أرقام في القائمة."))
            return
        }
        for (n in numbers) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(TextView(this).apply {
                text = n
                textSize = 17f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    Settings.removeFromList(this@MainActivity, listKey, n)
                    refreshLists()
                }
            })
            container.addView(row)
        }
    }
}
