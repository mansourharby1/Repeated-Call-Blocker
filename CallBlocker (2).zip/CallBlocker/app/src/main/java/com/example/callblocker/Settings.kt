package com.example.callblocker

import android.content.Context
import java.util.Calendar
import java.util.Locale

object Settings {
    private const val PREFS = "settings"

    const val WHITE = "whitelist"
    const val BLACK = "blacklist"

    const val DEFAULT_MINUTES = 30
    const val DURATION_TAG = "{المدة}"
    const val DEFAULT_TEMPLATE = "أهلا وسهلا بك يرجى الاتصال بعد {المدة} من الآن شكرا لك"

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------- تشغيل / إيقاف سريع ----------
    fun isEnabled(c: Context) = p(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()

    // ---------- المدة ----------
    fun getMinutes(c: Context): Int = p(c).getInt("minutes", DEFAULT_MINUTES)
    fun setMinutes(c: Context, v: Int) = p(c).edit().putInt("minutes", v).apply()

    // ---------- عدد المكالمات المسموحة قبل الحظر ----------
    fun getMaxCalls(c: Context): Int = p(c).getInt("max_calls", 1)
    fun setMaxCalls(c: Context, v: Int) = p(c).edit().putInt("max_calls", v).apply()

    // ---------- استثناء جهات الاتصال ----------
    fun isContactsExempt(c: Context) = p(c).getBoolean("contacts_exempt", false)
    fun setContactsExempt(c: Context, v: Boolean) =
        p(c).edit().putBoolean("contacts_exempt", v).apply()

    // ---------- الإشعارات ----------
    fun isNotifyEnabled(c: Context) = p(c).getBoolean("notify", false)
    fun setNotify(c: Context, v: Boolean) = p(c).edit().putBoolean("notify", v).apply()

    // ---------- ساعات التفعيل ----------
    fun isAllDay(c: Context) = p(c).getBoolean("all_day", true)
    fun setAllDay(c: Context, v: Boolean) = p(c).edit().putBoolean("all_day", v).apply()
    fun getStart(c: Context): Int = p(c).getInt("start_min", 8 * 60)
    fun setStart(c: Context, v: Int) = p(c).edit().putInt("start_min", v).apply()
    fun getEnd(c: Context): Int = p(c).getInt("end_min", 22 * 60)
    fun setEnd(c: Context, v: Int) = p(c).edit().putInt("end_min", v).apply()

    fun formatTime(minutes: Int): String =
        String.format(Locale.ENGLISH, "%02d:%02d", minutes / 60, minutes % 60)

    fun isActiveNow(c: Context): Boolean {
        if (isAllDay(c)) return true
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val s = getStart(c)
        val e = getEnd(c)
        return when {
            s == e -> true               // نفس الوقت = اليوم كله
            s < e -> now in s until e    // مثال 08:00 إلى 22:00
            else -> now >= s || now < e  // يمتد بعد منتصف الليل مثل 22:00 إلى 06:00
        }
    }

    // ---------- نص الرسالة ----------
    fun getCustomMessage(c: Context): String = p(c).getString("message", "") ?: ""
    fun setCustomMessage(c: Context, v: String) = p(c).edit().putString("message", v).apply()

    fun durationPhrase(minutes: Int): String = when (minutes) {
        30 -> "نصف ساعة"
        60 -> "ساعة"
        120 -> "ساعتين"
        else -> "$minutes دقيقة"
    }

    fun replyText(c: Context): String {
        val template = getCustomMessage(c).trim().ifEmpty { DEFAULT_TEMPLATE }
        return template.replace(DURATION_TAG, durationPhrase(getMinutes(c)))
    }

    // ---------- القائمة البيضاء والسوداء ----------
    fun getList(c: Context, listKey: String): List<String> =
        (p(c).getStringSet(listKey, emptySet()) ?: emptySet()).toList().sorted()

    private fun saveList(c: Context, listKey: String, set: Set<String>) =
        p(c).edit().putStringSet(listKey, set).apply()

    /** يضيف الرقم للقائمة ويزيله من القائمة الأخرى لتجنب التعارض */
    fun addToList(c: Context, listKey: String, number: String): Boolean {
        val cleaned = clean(number)
        if (digitsOnly(cleaned).length < 3) return false
        val k = key(cleaned)

        val set = getList(c, listKey).toMutableSet()
        set.add(cleaned)
        saveList(c, listKey, set)

        val otherKey = if (listKey == WHITE) BLACK else WHITE
        val other = getList(c, otherKey).filter { key(it) != k }.toSet()
        saveList(c, otherKey, other)
        return true
    }

    fun removeFromList(c: Context, listKey: String, number: String) {
        val set = getList(c, listKey).toMutableSet()
        set.remove(number)
        saveList(c, listKey, set)
    }

    fun inList(c: Context, listKey: String, number: String): Boolean {
        val k = key(number)
        if (k.isEmpty()) return false
        return getList(c, listKey).any { key(it) == k }
    }

    // ---------- أدوات الأرقام ----------
    /** يحوّل الأرقام العربية إلى إنجليزية ويُبقي الأرقام وعلامة + فقط */
    fun clean(number: String): String {
        val sb = StringBuilder()
        for (ch in number.trim()) {
            val d = Character.digit(ch, 10)
            when {
                d >= 0 -> sb.append(d)
                ch == '+' && sb.isEmpty() -> sb.append('+')
            }
        }
        return sb.toString()
    }

    private fun digitsOnly(number: String) = clean(number).filter { it.isDigit() }

    /** مفتاح المقارنة: آخر 9 أرقام، ليتطابق 010xxxxxxxx مع +2010xxxxxxxx */
    fun key(number: String): String = digitsOnly(number).takeLast(9)
}
