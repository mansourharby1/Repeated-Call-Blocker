package com.example.callblocker

import android.content.Context
import org.json.JSONObject

object LogStore {
    private const val PREFS = "log"
    private const val KEY = "entries"
    private const val MAX_ENTRIES = 200

    const val R_REPEAT = "repeat"
    const val R_BLACK = "black"

    data class Entry(val number: String, val last: Long, val count: Int, val reason: String)

    fun label(reason: String) =
        if (reason == R_BLACK) "قائمة سوداء" else "اتصال متكرر"

    private fun load(c: Context): JSONObject {
        val s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        return try {
            if (s == null) JSONObject() else JSONObject(s)
        } catch (e: Exception) {
            JSONObject()
        }
    }

    private fun save(c: Context, obj: JSONObject) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, obj.toString()).apply()
    }

    @Synchronized
    fun add(c: Context, number: String, reason: String) {
        val k = Settings.key(number)
        if (k.isEmpty()) return
        val obj = load(c)
        val oldCount = obj.optJSONObject(k)?.optInt("c", 0) ?: 0
        val e = JSONObject()
            .put("n", number)
            .put("t", System.currentTimeMillis())
            .put("c", oldCount + 1)
            .put("r", reason)
        obj.put(k, e)

        while (obj.length() > MAX_ENTRIES) {
            var oldestKey: String? = null
            var oldest = Long.MAX_VALUE
            val keys = obj.keys()
            while (keys.hasNext()) {
                val kk = keys.next()
                val t = obj.getJSONObject(kk).optLong("t")
                if (t < oldest) {
                    oldest = t
                    oldestKey = kk
                }
            }
            if (oldestKey == null) break
            obj.remove(oldestKey)
        }
        save(c, obj)
    }

    @Synchronized
    fun list(c: Context): List<Entry> {
        val obj = load(c)
        val out = ArrayList<Entry>()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val e = obj.getJSONObject(keys.next())
            out.add(Entry(e.optString("n"), e.optLong("t"), e.optInt("c"), e.optString("r")))
        }
        return out.sortedByDescending { it.last }
    }

    @Synchronized
    fun clear(c: Context) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
