package com.example.callblocker

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

object Notifier {
    private const val CHANNEL = "blocked_calls"

    fun notifyBlocked(c: Context, number: String, reason: String) {
        if (!Settings.isNotifyEnabled(c)) return
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return

        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "المكالمات المحظورة", NotificationManager.IMPORTANCE_DEFAULT)
            )
            val pi = PendingIntent.getActivity(
                c, 0, Intent(c, LogActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.sym_call_missed)
                .setContentTitle("تم حظر مكالمة")
                .setContentText("$number - ${LogStore.label(reason)}")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(Settings.key(number).hashCode(), n)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
