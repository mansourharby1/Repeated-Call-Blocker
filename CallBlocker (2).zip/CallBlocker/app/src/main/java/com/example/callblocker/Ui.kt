package com.example.callblocker

import android.content.Context
import android.widget.TextView

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.titleView(text: String) = TextView(this).apply {
    this.text = text
    textSize = 20f
    setPadding(0, dp(24), 0, dp(8))
}

fun Context.bodyView(text: String) = TextView(this).apply {
    this.text = text
    textSize = 15f
    setPadding(0, dp(4), 0, dp(4))
}
